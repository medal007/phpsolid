<?php
header("Location:/");
?>